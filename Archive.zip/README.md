# App name

Zest App for Zendesk.

Run zcli apps:server  
zcli apps:server 



